

<?php $__env->startSection('title', 'My Listings'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.donor_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title h4 mb-0">My food listings <span class="text-muted fs-6">(GET /food/mine)</span></h1>
    <a href="<?php echo e(url('/donor/donations/create')); ?>" class="btn btn-brand">Post food</a>
</div>

<div class="card page-card">
    <div class="card-body p-0">
        <?php echo $__env->make('partials.listings_table', ['listings' => $listings, 'showDeliverButton' => true, 'showClaimInfo' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\donor\donations\index.blade.php ENDPATH**/ ?>