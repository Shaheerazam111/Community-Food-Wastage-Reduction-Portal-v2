

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1 class="page-title h4 mb-1">Admin dashboard</h1>
        <p class="small text-muted mb-0">Snapshot for <?php echo e($from); ?> to <?php echo e($to); ?> (listings created in this range).</p>
    </div>
    <a href="<?php echo e(route('admin.reports', ['from' => $from, 'to' => $to])); ?>" class="btn btn-brand">Open full reports</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-6 col-md-4 col-xl-2">
        <div class="stat-card">
            <div class="text-muted small">Listings posted</div>
            <div class="fs-4"><?php echo e($summary['total_listings']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="stat-card">
            <div class="text-muted small">Delivered</div>
            <div class="fs-4 text-success"><?php echo e($summary['delivered']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="stat-card">
            <div class="text-muted small">Claim rate</div>
            <div class="fs-4"><?php echo e($summary['claim_rate_pct']); ?>%</div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="stat-card">
            <div class="text-muted small">Donors (all)</div>
            <div class="fs-4"><?php echo e($summary['donors_total']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="stat-card">
            <div class="text-muted small">NGOs (all)</div>
            <div class="fs-4"><?php echo e($summary['recipients_total']); ?></div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-xl-2">
        <div class="stat-card">
            <div class="text-muted small">Expired</div>
            <div class="fs-4 text-muted"><?php echo e($summary['expired']); ?></div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-12 col-lg-5">
        <div class="card page-card h-100">
            <div class="card-header"><strong>By status</strong></div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $byStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $pct = $summary['total_listings'] > 0
                            ? round(($row->total / $summary['total_listings']) * 100, 1)
                            : 0;
                    ?>
                    <div class="report-bar-row mb-2">
                        <div class="d-flex justify-content-between small mb-1">
                            <?php
                                $badge = match ($row->status) {
                                    'AVAILABLE' => 'badge-available',
                                    'CLAIMED' => 'badge-claimed',
                                    'DELIVERED' => 'badge-delivered',
                                    'EXPIRED' => 'badge-expired',
                                    default => 'badge-closed',
                                };
                            ?>
                            <span><span class="badge <?php echo e($badge); ?>"><?php echo e($row->status); ?></span></span>
                            <span><?php echo e($row->total); ?> (<?php echo e($pct); ?>%)</span>
                        </div>
                        <div class="report-bar-track">
                            <div class="report-bar-fill" style="width: <?php echo e($pct); ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted small mb-0">No listings in this period yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-7">
        <div class="card page-card h-100">
            <div class="card-header"><strong>What you can do here</strong></div>
            <div class="card-body small">
                <p>Reports read live data from <code>food_listings</code> and <code>users</code> — same records donors and NGOs create through the portal API.</p>
                <ul class="mb-0">
                    <li>Filter by date range on the <a href="<?php echo e(route('admin.reports')); ?>">Reports</a> page (max <?php echo e(\App\Services\AdminReportService::MAX_RANGE_DAYS); ?> days).</li>
                    <li>See trends, top donors/NGOs, pickup areas, and export CSV for your assignment write-up.</li>
                    <li>Demo accounts (admin, donor, NGO, volunteer) come from <code>php artisan db:seed --class=UserSeeder</code> — not the public register form.</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>