<div class="api-panel" data-api-id="<?php echo e($api['id']); ?>">
    <div class="api-header" onclick="toggleApi(this.parentElement)">
        <span class="badge badge-<?php echo e(strtolower($api['method'])); ?>"><?php echo e($api['method']); ?></span>
        <span class="api-title"><?php echo e($api['name']); ?></span>
        <code style="font-size:.78rem;color:var(--muted)"><?php echo e($api['path']); ?></code>
        <span class="chevron">▶</span>
    </div>
    <div class="api-body">
        <p class="api-desc"><?php echo e($api['description']); ?></p>
        <div class="api-meta">
            <span class="badge badge-task"><?php echo e($api['task']); ?></span>
            <?php if(!empty($api['challenge'])): ?>
                <span class="badge badge-challenge"><?php echo e($api['challenge']); ?></span>
            <?php endif; ?>
            <?php if(!empty($api['auth'])): ?>
                · Requires login <?php if(!empty($api['role'])): ?> (<?php echo e($api['role']); ?>) <?php endif; ?>
            <?php else: ?>
                · Public
            <?php endif; ?>
            · Expected: <code><?php echo e($api['expects']); ?></code>
        </div>

        <?php if(!empty($api['fields'])): ?>
            <form class="api-form" data-api="<?php echo e($api['id']); ?>"
                  data-method="<?php echo e($api['method']); ?>"
                  data-path="<?php echo e($api['path']); ?>"
                  <?php if(!empty($api['capture'])): ?> data-capture="<?php echo e($api['capture']); ?>" <?php endif; ?>
                  <?php if(!empty($api['usesListingId'])): ?> data-uses-listing-id="1" <?php endif; ?>
                  <?php if(!empty($api['showMap'])): ?> data-show-map="1" <?php endif; ?>
                  <?php if(!empty($api['mapPicker'])): ?> data-map-picker="1" <?php endif; ?>>
                <?php $__currentLoopData = $api['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <label><?php echo e($field['label']); ?></label>
                        <?php if(($field['type'] ?? '') === 'hidden'): ?>
                            <input type="hidden" name="<?php echo e($field['name']); ?>" value="<?php echo e($field['default']); ?>">
                        <?php elseif(($field['type'] ?? '') === 'select'): ?>
                            <select name="<?php echo e($field['name']); ?>">
                                <?php $__currentLoopData = $field['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($val); ?>" <?php if(($field['default'] ?? '') === $val): ?> selected <?php endif; ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php else: ?>
                            <input type="<?php echo e($field['type'] ?? 'text'); ?>"
                                   name="<?php echo e($field['name']); ?>"
                                   value="<?php echo e(($field['default'] ?? '') !== '+1hour' ? ($field['default'] ?? '') : ''); ?>"
                                   <?php if(!empty($field['step'])): ?> step="<?php echo e($field['step']); ?>" <?php endif; ?>
                                   <?php if(!empty($field['required'])): ?> required <?php endif; ?>
                                   <?php if(($field['default'] ?? '') === '+1hour'): ?> data-default-offset="3600000" <?php endif; ?>
                                   <?php if(!empty($api['mapPicker']) && in_array($field['name'], ['latitude', 'longitude'])): ?> readonly <?php endif; ?>>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php echo $__env->make('test-apis.partials.donor-location', ['api' => $api], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('test-apis.partials.map-blocks', ['api' => $api], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('test-apis.partials.listing-picker', ['api' => $api], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div style="display:flex;align-items:flex-end">
                    <button type="submit" class="btn btn-primary">Send request</button>
                </div>
            </form>
        <?php else: ?>
            <?php echo $__env->make('test-apis.partials.listing-picker', ['api' => $api], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div style="margin-bottom:.75rem">
                <button type="button" class="btn btn-primary btn-send-no-form"
                        data-api="<?php echo e($api['id']); ?>"
                        data-method="<?php echo e($api['method']); ?>"
                        data-path="<?php echo e($api['path']); ?>"
                        <?php if(!empty($api['usesListingId'])): ?> data-uses-listing-id="1" <?php endif; ?>>Send request</button>
            </div>
        <?php endif; ?>

        <div class="response-box" id="response-<?php echo e($api['id']); ?>">No request sent yet.</div>
    </div>
</div>
<?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views/test-apis/partials/api-panel.blade.php ENDPATH**/ ?>