

<?php $__env->startSection('title', 'NGO verification'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.recipient_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title h4 mb-0">NGO verification</h1>
</div>

<div class="card page-card mb-4">
    <div class="card-body">
        <p class="mb-2">Your account status: <strong><?php echo e($user->verification_status); ?></strong></p>
        <?php if($user->verification_status === 'pending'): ?>
            <p class="small text-muted mb-0">An admin is reviewing your document. You can browse food but cannot claim until approved.</p>
        <?php elseif($user->verification_status === 'rejected'): ?>
            <p class="small text-danger mb-0">Upload a clearer registration certificate or NGO letter below.</p>
        <?php else: ?>
            <p class="small text-muted mb-0">You are verified and can claim food.</p>
        <?php endif; ?>
    </div>
</div>

<?php if($document): ?>
<div class="card page-card mb-4">
    <div class="card-header"><strong>Latest upload</strong></div>
    <div class="card-body small">
        <div>File: <?php echo e($document->original_name ?? 'document'); ?></div>
        <div>Review status: <?php echo e($document->status); ?></div>
        <?php if($document->admin_note): ?>
            <div>Admin note: <?php echo e($document->admin_note); ?></div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php if($user->verification_status !== 'approved'): ?>
<div class="card page-card">
    <div class="card-body">
        <h2 class="h6">Upload verification document</h2>
        <p class="small text-muted">PDF or image, max 5 MB. Only admins can view this file.</p>
        <form method="POST" action="<?php echo e(url('/recipient/verification')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <input type="file" class="form-control" name="verification_document" accept=".pdf,image/*" required>
            </div>
            <button type="submit" class="btn btn-brand">Upload</button>
        </form>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views/recipient/verification/show.blade.php ENDPATH**/ ?>