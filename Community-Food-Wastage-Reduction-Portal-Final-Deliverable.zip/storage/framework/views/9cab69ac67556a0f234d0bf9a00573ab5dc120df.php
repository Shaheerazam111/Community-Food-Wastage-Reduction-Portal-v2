

<?php $__env->startSection('title', 'Moderate listings'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title h4 mb-0">Moderate food listings</h1>
</div>

<p class="small text-muted">New donor posts stay <strong>PENDING</strong> until approved. Only approved listings appear in NGO search.</p>

<div class="card page-card mb-4">
    <div class="card-header"><strong>Pending approval</strong></div>
    <div class="card-body p-0 table-responsive">
        <table class="table table-sm mb-0">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Donor</th>
                    <th>Qty</th>
                    <th>Expires</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($listing->title); ?></td>
                        <td class="small"><?php echo e($listing->donor->business_name ?? $listing->donor->name); ?></td>
                        <td><?php echo e($listing->quantity); ?></td>
                        <td class="small"><?php echo e($listing->expiry_at->format('Y-m-d H:i')); ?></td>
                        <td class="text-end">
                            <form method="POST" action="<?php echo e(route('admin.listings.update', $listing->id)); ?>" class="d-inline-flex flex-wrap gap-1 justify-content-end">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="rejection_reason" class="form-control form-control-sm" placeholder="Reject reason" style="max-width: 12rem;">
                                <button type="submit" name="action" value="approve" class="btn btn-sm btn-brand">Approve</button>
                                <button type="submit" name="action" value="reject" class="btn btn-sm btn-outline-danger" data-confirm="Reject this listing?">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="text-muted p-3">No listings waiting for review.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card page-card">
    <div class="card-header"><strong>Recently moderated</strong></div>
    <div class="card-body p-0 table-responsive">
        <table class="table table-sm mb-0">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Status</th>
                    <th>Reason</th>
                    <th>When</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($listing->title); ?></td>
                        <td><?php echo e($listing->moderation_status); ?></td>
                        <td class="small"><?php echo e($listing->rejection_reason ?? '—'); ?></td>
                        <td class="small"><?php echo e($listing->moderated_at?->format('Y-m-d H:i') ?? '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="text-muted p-3">No history yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\admin\listings\index.blade.php ENDPATH**/ ?>