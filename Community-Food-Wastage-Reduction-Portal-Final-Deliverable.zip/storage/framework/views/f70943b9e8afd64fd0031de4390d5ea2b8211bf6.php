

<?php $__env->startSection('title', 'Admin Reports'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1 class="page-title h4 mb-1">Reports &amp; analytics</h1>
        <p class="small text-muted mb-0">Food listings created between <?php echo e($from); ?> and <?php echo e($to); ?>.</p>
    </div>
    <a href="<?php echo e(route('admin.reports.export', ['from' => $from, 'to' => $to])); ?>" class="btn btn-outline-brand">Download CSV</a>
</div>

<div class="card page-card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.reports')); ?>" class="row g-3 align-items-end">
            <div class="col-12 col-md-4">
                <label for="from" class="form-label">From</label>
                <input type="date" class="form-control" id="from" name="from" value="<?php echo e($from); ?>" required>
            </div>
            <div class="col-12 col-md-4">
                <label for="to" class="form-label">To</label>
                <input type="date" class="form-control" id="to" name="to" value="<?php echo e($to); ?>" required>
            </div>
            <div class="col-12 col-md-4 d-grid d-md-block">
                <button type="submit" class="btn btn-brand">Update report</button>
            </div>
        </form>
        <p class="form-text mb-0 mt-2">If the range is too long, the start date is trimmed to <?php echo e(\App\Services\AdminReportService::MAX_RANGE_DAYS); ?> days.</p>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="stat-card">
            <div class="text-muted small">Total posted</div>
            <div class="fs-4"><?php echo e($summary['total_listings']); ?></div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card">
            <div class="text-muted small">Delivered</div>
            <div class="fs-4"><?php echo e($summary['delivered']); ?></div>
            <div class="small text-muted">Delivery rate (of claimed+delivered): <?php echo e($summary['delivery_rate_pct']); ?>%</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card">
            <div class="text-muted small">Claim rate</div>
            <div class="fs-4"><?php echo e($summary['claim_rate_pct']); ?>%</div>
            <div class="small text-muted"><?php echo e($summary['claimed']); ?> still claimed · <?php echo e($summary['available']); ?> available</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat-card">
            <div class="text-muted small">New users in range</div>
            <div class="fs-5"><?php echo e($summary['donors_new']); ?> donors · <?php echo e($summary['recipients_new']); ?> NGOs</div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-xl-8">
        <div class="card page-card">
            <div class="card-header"><strong>Listings per day</strong></div>
            <div class="card-body">
                <?php if($dailyTrend->isEmpty()): ?>
                    <p class="text-muted small mb-0">No listings in this date range.</p>
                <?php else: ?>
                    <div class="report-trend" aria-hidden="true">
                        <?php $__currentLoopData = $dailyTrend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $h = max(4, round(($day->total / $maxTrend) * 100));
                            ?>
                            <div class="report-trend-col" title="<?php echo e($day->day); ?>: <?php echo e($day->total); ?>">
                                <div class="report-trend-bar" style="height: <?php echo e($h); ?>%"></div>
                                <span class="report-trend-label"><?php echo e(\Illuminate\Support\Str::substr($day->day, 5)); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-12 col-xl-4">
        <div class="card page-card mb-3">
            <div class="card-header"><strong>By category</strong></div>
            <div class="card-body p-0">
                <table class="table table-sm mb-0">
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $byCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($row->category === 'veg' ? 'Vegetarian' : 'Non-veg'); ?></td>
                                <td class="text-end"><?php echo e($row->total); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="text-muted small p-3">No data</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card page-card">
            <div class="card-header"><strong>By status</strong></div>
            <div class="card-body p-0">
                <table class="table table-sm mb-0">
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $byStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <?php
                                    $badge = match ($row->status) {
                                        'AVAILABLE' => 'badge-available',
                                        'CLAIMED' => 'badge-claimed',
                                        'DELIVERED' => 'badge-delivered',
                                        'EXPIRED' => 'badge-expired',
                                        default => 'badge-closed',
                                    };
                                ?>
                                <td><span class="badge <?php echo e($badge); ?>"><?php echo e($row->status); ?></span></td>
                                <td class="text-end"><?php echo e($row->total); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="text-muted small p-3">No data</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-lg-6">
        <div class="card page-card">
            <div class="card-header"><strong>Top pickup areas</strong></div>
            <div class="card-body p-0 table-responsive">
                <table class="table table-sm mb-0">
                    <thead>
                        <tr>
                            <th>Address</th>
                            <th class="text-end">Listings</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $byArea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="small"><?php echo e($row->pickup_address); ?></td>
                                <td class="text-end"><?php echo e($row->total); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="2" class="text-muted small p-3">No data</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-6">
        <div class="card page-card">
            <div class="card-header"><strong>Top donors</strong></div>
            <div class="card-body p-0 table-responsive">
                <table class="table table-sm mb-0">
                    <thead>
                        <tr>
                            <th>Donor</th>
                            <th class="text-end">Posted</th>
                            <th class="text-end">Delivered</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $topDonors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="small"><?php echo e($row->business_name ?: $row->name); ?></td>
                                <td class="text-end"><?php echo e($row->listings); ?></td>
                                <td class="text-end"><?php echo e($row->delivered); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="3" class="text-muted small p-3">No donors in range</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-lg-6">
        <div class="card page-card">
            <div class="card-header"><strong>Top NGOs (by claims)</strong></div>
            <div class="card-body p-0 table-responsive">
                <table class="table table-sm mb-0">
                    <thead>
                        <tr>
                            <th>NGO</th>
                            <th class="text-end">Claims</th>
                            <th class="text-end">Delivered</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $topRecipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="small"><?php echo e($row->ngo_name ?: $row->name); ?></td>
                                <td class="text-end"><?php echo e($row->claims); ?></td>
                                <td class="text-end"><?php echo e($row->delivered); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="3" class="text-muted small p-3">No claims in range</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-6">
        <div class="card page-card">
            <div class="card-header"><strong>Recent listings</strong></div>
            <div class="card-body p-0 table-responsive">
                <table class="table table-sm mb-0 align-middle">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Status</th>
                            <th>Donor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentListings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="small"><?php echo e($row->title); ?></td>
                                <?php
                                    $badge = match ($row->status) {
                                        'AVAILABLE' => 'badge-available',
                                        'CLAIMED' => 'badge-claimed',
                                        'DELIVERED' => 'badge-delivered',
                                        'EXPIRED' => 'badge-expired',
                                        default => 'badge-closed',
                                    };
                                ?>
                                <td><span class="badge <?php echo e($badge); ?>"><?php echo e($row->status); ?></span></td>
                                <td class="small"><?php echo e($row->donor_name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="3" class="text-muted small p-3">No listings</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>