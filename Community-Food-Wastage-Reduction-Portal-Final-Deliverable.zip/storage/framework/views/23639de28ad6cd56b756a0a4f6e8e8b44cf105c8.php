

<?php $__env->startSection('title', 'NGO verification'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title h4 mb-0">NGO document review</h1>
</div>

<p class="small text-muted">Only admins can download verification files. Approve before the NGO can claim food.</p>

<div class="card page-card">
    <div class="card-body p-0 table-responsive">
        <table class="table table-sm mb-0 align-middle">
            <thead>
                <tr>
                    <th>NGO</th>
                    <th>Email</th>
                    <th>Doc status</th>
                    <th>User status</th>
                    <th>Uploaded</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($doc->user->ngo_name ?? $doc->user->name); ?></td>
                        <td class="small"><?php echo e($doc->user->email); ?></td>
                        <td><?php echo e($doc->status); ?></td>
                        <td><?php echo e($doc->user->verification_status); ?></td>
                        <td class="small"><?php echo e($doc->created_at->format('Y-m-d H:i')); ?></td>
                        <td class="text-end">
                            <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('admin.verification.download', $doc->id)); ?>">Download</a>
                            <?php if($doc->status === 'pending'): ?>
                                <form method="POST" action="<?php echo e(route('admin.verification.update', $doc->id)); ?>" class="d-inline-flex gap-1 flex-wrap justify-content-end mt-1">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="admin_note" class="form-control form-control-sm" placeholder="Note (optional)" style="max-width: 10rem;">
                                    <button type="submit" name="action" value="approve" class="btn btn-sm btn-brand">Approve</button>
                                    <button type="submit" name="action" value="reject" class="btn btn-sm btn-outline-danger" data-confirm="Reject this NGO document?">Reject</button>
                                </form>
                            <?php else: ?>
                                <span class="small text-muted d-block"><?php echo e($doc->admin_note ?: '—'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" class="text-muted p-3">No documents uploaded yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($documents->hasPages()): ?>
        <div class="card-footer"><?php echo e($documents->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views/admin/verification/index.blade.php ENDPATH**/ ?>