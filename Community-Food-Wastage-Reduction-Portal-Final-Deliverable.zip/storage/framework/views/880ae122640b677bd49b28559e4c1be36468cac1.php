

<?php $__env->startSection('title', 'My Claims'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.recipient_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title h4 mb-0">My claimed food <span class="text-muted fs-6">(GET /food/claims)</span></h1>
    <a href="<?php echo e(url('/recipient/food')); ?>" class="btn btn-outline-secondary">Find more food</a>
</div>

<p class="small text-muted">
    After you claim, status is <strong>CLAIMED</strong> until the donor marks <strong>DELIVERED</strong>.
    Claimed items disappear from search (Task 3 — not shown when already claimed).
</p>

<div class="card page-card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped mb-0">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Qty</th>
                        <th>Status</th>
                        <th>Claimed at</th>
                        <th>Pickup</th>
                        <th>Donor</th>
                        <th>Feedback</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $claims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $badge = match ($claim->status) {
                                'CLAIMED' => 'badge-claimed',
                                'DELIVERED' => 'badge-delivered',
                                'EXPIRED' => 'badge-expired',
                                default => 'badge-closed',
                            };
                            $donor = $claim->donor;
                        ?>
                        <tr>
                            <td><?php echo e($claim->title); ?></td>
                            <td><?php echo e($claim->quantity); ?></td>
                            <td><span class="badge badge-status <?php echo e($badge); ?>"><?php echo e($claim->status); ?></span></td>
                            <td class="small"><?php echo e($claim->claimed_at?->format('Y-m-d H:i') ?? '—'); ?></td>
                            <td class="small">
                                <?php echo e($claim->pickup_address); ?><br>
                                <span class="text-muted"><?php echo e($claim->latitude); ?>, <?php echo e($claim->longitude); ?></span>
                            </td>
                            <td class="small">
                                <?php if($donor): ?>
                                    <?php echo e($donor->business_name ?? $donor->name); ?><br>
                                    <?php if($donor->phone): ?>
                                        <?php echo e($donor->phone); ?><br>
                                    <?php endif; ?>
                                    <?php echo e($donor->address); ?>

                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td class="small">
                                <?php
                                    $myFeedback = $claim->feedbacks->where('recipient_id', auth()->id())->first();
                                ?>
                                <?php if($claim->status === 'DELIVERED' && ! $myFeedback): ?>
                                    <form method="POST" action="<?php echo e(url('/food/'.$claim->id.'/feedback')); ?>" class="d-flex flex-column gap-1">
                                        <?php echo csrf_field(); ?>
                                        <select name="rating" class="form-select form-select-sm" required>
                                            <option value="">Rating</option>
                                            <?php for($r = 5; $r >= 1; $r--): ?>
                                                <option value="<?php echo e($r); ?>"><?php echo e($r); ?> stars</option>
                                            <?php endfor; ?>
                                        </select>
                                        <input type="text" name="comment" class="form-control form-control-sm" placeholder="Short comment">
                                        <button type="submit" class="btn btn-sm btn-outline-brand">Submit</button>
                                    </form>
                                <?php elseif($myFeedback): ?>
                                    <?php echo e($myFeedback->rating); ?>/5 — <?php echo e($myFeedback->comment ?: 'No comment'); ?>

                                <?php else: ?>
                                    <span class="text-muted">After delivery</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-muted p-3">
                                No claims yet. Use <a href="<?php echo e(url('/recipient/food')); ?>">Find food</a> and press Claim.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views/recipient/claims/index.blade.php ENDPATH**/ ?>