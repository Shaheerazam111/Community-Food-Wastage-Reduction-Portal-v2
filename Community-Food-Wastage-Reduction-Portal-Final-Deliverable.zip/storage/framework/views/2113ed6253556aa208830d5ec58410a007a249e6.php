

<?php $__env->startSection('title', 'Donor Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.donor_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title h4 mb-0">Donor dashboard</h1>
    <a href="<?php echo e(url('/donor/donations/create')); ?>" class="btn btn-brand">Post food</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-md-4">
        <div class="stat-card">
            <div class="text-muted small">Available</div>
            <div class="fs-4"><?php echo e($stats['available']); ?></div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="stat-card">
            <div class="text-muted small">Claimed</div>
            <div class="fs-4"><?php echo e($stats['claimed']); ?></div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="stat-card">
            <div class="text-muted small">Delivered</div>
            <div class="fs-4"><?php echo e($stats['delivered']); ?></div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="stat-card">
            <div class="text-muted small">Meals saved (est.)</div>
            <div class="fs-4"><?php echo e($stats['meals_saved'] ?? 0); ?></div>
            <div class="small text-muted">From delivered listing quantities</div>
        </div>
    </div>
</div>

<div class="card page-card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <strong>Recent listings</strong>
        <a href="<?php echo e(url('/food/mine')); ?>" class="small">View all (GET /food/mine)</a>
    </div>
    <div class="card-body p-0">
        <?php echo $__env->make('partials.listings_table', ['listings' => $listings, 'showDeliverButton' => true, 'showClaimInfo' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\donor\dashboard.blade.php ENDPATH**/ ?>