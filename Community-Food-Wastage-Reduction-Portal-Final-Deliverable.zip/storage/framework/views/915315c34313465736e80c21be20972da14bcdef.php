<li class="nav-item"><a class="nav-link <?php echo e(request()->is('donor/dashboard') ? 'active' : ''); ?>" href="<?php echo e(url('/donor/dashboard')); ?>">Dashboard</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->is('donor/donations/create') ? 'active' : ''); ?>" href="<?php echo e(url('/donor/donations/create')); ?>">Post food</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->is('food/mine') ? 'active' : ''); ?>" href="<?php echo e(url('/food/mine')); ?>">My listings</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->is('notifications') ? 'active' : ''); ?>" href="<?php echo e(url('/notifications')); ?>">Notifications</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->is('profile') ? 'active' : ''); ?>" href="<?php echo e(url('/profile')); ?>">Profile</a></li>
<?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views/partials/donor_nav.blade.php ENDPATH**/ ?>