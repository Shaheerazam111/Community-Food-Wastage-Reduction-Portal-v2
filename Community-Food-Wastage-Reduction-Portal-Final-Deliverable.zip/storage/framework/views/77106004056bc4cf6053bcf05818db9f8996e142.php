

<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.role_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title h4 mb-0">Notifications</h1>
</div>

<div class="card page-card">
    <div class="card-body p-0">
        <ul class="list-group list-group-flush">
            <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="list-group-item <?php echo e($note->read_at ? '' : 'bg-light'); ?>">
                    <div class="d-flex justify-content-between gap-3">
                        <div>
                            <strong><?php echo e($note->title); ?></strong>
                            <p class="small mb-1"><?php echo e($note->body); ?></p>
                            <span class="text-muted small"><?php echo e($note->created_at->format('Y-m-d H:i')); ?></span>
                        </div>
                        <?php if(! $note->read_at): ?>
                            <form method="POST" action="<?php echo e(url('/notifications/'.$note->id.'/read')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-outline-brand">Mark read</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="list-group-item text-muted">No notifications yet.</li>
            <?php endif; ?>
        </ul>
    </div>
    <?php if($notifications->hasPages()): ?>
        <div class="card-footer"><?php echo e($notifications->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views/notifications/index.blade.php ENDPATH**/ ?>