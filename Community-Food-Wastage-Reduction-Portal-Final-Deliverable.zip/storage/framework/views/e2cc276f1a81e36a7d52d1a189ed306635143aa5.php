
<?php
    $startLat = $latitude ?? 31.5204;
    $startLng = $longitude ?? 74.3587;
    $hasPin = isset($latitude) && isset($longitude) && $latitude !== '' && $longitude !== null;
?>
<div class="mb-1">
    <label class="form-label <?php echo e(! empty($required) ? 'required' : ''); ?>"><?php echo e($label ?? 'Pickup location on map'); ?></label>
    <p class="small text-muted mb-2">Click the map to drop a pin for this pickup spot.</p>
</div>
<div
    class="map-embed map-picker mb-2"
    data-map-picker
    data-lat="<?php echo e($hasPin ? $startLat : ''); ?>"
    data-lng="<?php echo e($hasPin ? $startLng : ''); ?>"
    data-default-lat="<?php echo e($startLat); ?>"
    data-default-lng="<?php echo e($startLng); ?>"
    role="application"
    aria-label="<?php echo e($label ?? 'Pickup location map'); ?>"
></div>
<input type="hidden" name="latitude" data-map-lat value="<?php echo e($hasPin ? $startLat : ''); ?>">
<input type="hidden" name="longitude" data-map-lng value="<?php echo e($hasPin ? $startLng : ''); ?>">
<p class="small text-muted mb-0" data-map-hint>
    <?php if($hasPin): ?>
        Pin set — click again to move it.
    <?php else: ?>
        No pin yet — click the map to choose a location.
    <?php endif; ?>
</p>
<?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\partials\map_picker.blade.php ENDPATH**/ ?>