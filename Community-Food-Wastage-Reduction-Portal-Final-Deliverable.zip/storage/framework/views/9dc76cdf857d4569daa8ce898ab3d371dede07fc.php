<?php if(auth()->guard()->check()): ?>
    <?php switch(auth()->user()->role):
        case ('admin'): ?>
            <?php echo $__env->make('partials.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
        <?php case ('donor'): ?>
            <?php echo $__env->make('partials.donor_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
        <?php case ('recipient'): ?>
            <?php echo $__env->make('partials.recipient_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
        <?php case ('volunteer'): ?>
            <?php echo $__env->make('partials.volunteer_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
    <?php endswitch; ?>
<?php endif; ?>
<?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\partials\role_nav.blade.php ENDPATH**/ ?>