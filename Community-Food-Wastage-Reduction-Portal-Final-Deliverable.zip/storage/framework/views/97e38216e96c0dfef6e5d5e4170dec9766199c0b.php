

<?php $__env->startSection('title', 'Manage users'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title h4 mb-0">Manage users</h1>
</div>

<p class="small text-muted">Block inactive NGOs or donors. Verification documents are Phase 2 — use active flag for now.</p>

<div class="card page-card">
    <div class="card-body p-0 table-responsive">
        <table class="table table-sm mb-0">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->role); ?></td>
                        <td>
                            <?php if($user->is_active): ?>
                                <span class="badge badge-available">Active</span>
                            <?php else: ?>
                                <span class="badge badge-blocked">Blocked</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="is_active" value="<?php echo e($user->is_active ? '0' : '1'); ?>">
                                <button type="submit" class="btn btn-sm btn-outline-secondary" data-confirm="Change this user’s active status?">
                                    <?php echo e($user->is_active ? 'Block' : 'Unblock'); ?>

                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php if($users->hasPages()): ?>
        <div class="card-footer"><?php echo e($users->links()); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\admin\users\index.blade.php ENDPATH**/ ?>