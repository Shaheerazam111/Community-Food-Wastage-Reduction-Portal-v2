
<div class="table-responsive">
    <table class="table table-striped mb-0">
        <thead>
            <tr>
                <th>Title</th>
                <th>Category</th>
                <th>Quantity</th>
                <?php if(! empty($showClaimInfo)): ?>
                    <th>Pickup</th>
                <?php endif; ?>
                <th>Expires</th>
                <th>Status</th>
                <?php if(! empty($showDeliverButton)): ?>
                    <th>Admin</th>
                <?php endif; ?>
                <?php if(! empty($showClaimInfo)): ?>
                    <th>Claimed by</th>
                <?php endif; ?>
                <?php if(! empty($showDeliverButton)): ?>
                    <th></th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $status = $listing->status;
                    $badge = match ($status) {
                        'AVAILABLE' => 'badge-available',
                        'CLAIMED' => 'badge-claimed',
                        'DELIVERED' => 'badge-delivered',
                        'EXPIRED' => 'badge-expired',
                        default => 'badge-closed',
                    };
                    $expiry = $listing->expiry_at;
                    $expiryText = $expiry instanceof \DateTimeInterface ? $expiry->format('Y-m-d H:i') : (string) $expiry;
                    $claimer = $listing->relationLoaded('claimedBy') ? $listing->claimedBy : null;
                ?>
                <tr>
                    <td><?php echo e($listing->title); ?></td>
                    <td><?php echo e($listing->category === 'non_veg' ? 'Non-veg' : 'Veg'); ?></td>
                    <td><?php echo e($listing->quantity); ?></td>
                    <?php if(! empty($showClaimInfo)): ?>
                        <td class="small"><?php echo e($listing->pickup_address); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($expiryText); ?></td>
                    <td><span class="badge badge-status <?php echo e($badge); ?>"><?php echo e($status); ?></span></td>
                    <?php if(! empty($showDeliverButton)): ?>
                        <td class="small"><?php echo e($listing->moderation_status ?? '—'); ?></td>
                    <?php endif; ?>
                    <?php if(! empty($showClaimInfo)): ?>
                        <td class="small">
                            <?php if($claimer): ?>
                                <?php echo e($claimer->ngo_name ?? $claimer->name); ?>

                            <?php elseif($status === 'AVAILABLE'): ?>
                                <span class="text-muted">—</span>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                    <?php if(! empty($showDeliverButton)): ?>
                        <td class="col-actions">
                            <?php if($status === 'CLAIMED'): ?>
                                <form method="POST" action="<?php echo e(url('/food/'.$listing->id.'/deliver')); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-brand" data-confirm="Mark this listing as DELIVERED?">Mark delivered</button>
                                </form>
                            <?php elseif($status === 'AVAILABLE'): ?>
                                <form method="POST" action="<?php echo e(url('/food/'.$listing->id.'/cancel')); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-secondary" data-confirm="Cancel this listing? It will no longer appear in search.">Cancel</button>
                                </form>
                            <?php else: ?>
                                <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <?php
                        $cols = 5;
                        if (! empty($showClaimInfo)) {
                            $cols += 2;
                        }
                        if (! empty($showDeliverButton)) {
                            $cols += 1;
                        }
                    ?>
                    <td colspan="<?php echo e($cols); ?>" class="text-muted p-3">No listings yet.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\partials\listings_table.blade.php ENDPATH**/ ?>