

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="auth-center">
    <div class="auth-box">
        <div class="card page-card">
            <div class="card-body">
                <h1 class="page-title h4">Login</h1>
                <p class="small text-muted">Form posts to <strong>POST /auth/login</strong> (same as Postman).</p>
                <p class="form-hint"><span class="text-danger">*</span> Required fields</p>
                <form method="POST" action="<?php echo e(url('/auth/login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="email" class="form-label required">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="username">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label required">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required autocomplete="current-password">
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-brand">Login</button>
                    </div>
                </form>
                <p class="mt-3 mb-0 small">No account? <a href="<?php echo e(url('/register')); ?>">Register</a></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\auth\login.blade.php ENDPATH**/ ?>