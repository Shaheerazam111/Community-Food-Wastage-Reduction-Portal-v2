<?php if(!empty($api['usesDonorLocation'])): ?>
    <div class="donor-location-box" id="donor-location-<?php echo e($api['id']); ?>">
        Pickup location will be taken from your logged-in donor profile.
    </div>
<?php endif; ?>
<?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\test-apis\partials\donor-location.blade.php ENDPATH**/ ?>