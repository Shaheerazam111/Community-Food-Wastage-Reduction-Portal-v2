

<?php $__env->startSection('title', 'Post Food'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.donor_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title h4 mb-0">Post food</h1>
</div>

<div class="card page-card">
    <div class="card-body">
        <p class="small text-muted mb-3">
            Submits to <strong>POST /food</strong>. Pickup address and coordinates are taken from your donor profile (Task 2).
        </p>
        <?php if(auth()->guard()->check()): ?>
        <div class="alert alert-light border small mb-3">
            <strong>Pickup sent with this listing:</strong><br>
            Address: <?php echo e(auth()->user()->address ?? '—'); ?><br>
            Latitude: <?php echo e(auth()->user()->latitude ?? '—'); ?>,
            Longitude: <?php echo e(auth()->user()->longitude ?? '—'); ?>

        </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(url('/food')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="title" class="form-label required">Food title</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title')); ?>" required placeholder="e.g. 20 lunch boxes">
            </div>
            <div class="mb-3">
                <label class="form-label required">Category</label>
                <div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="category" id="cat_veg" value="veg" <?php echo e(old('category', 'veg') === 'veg' ? 'checked' : ''); ?> required>
                        <label class="form-check-label" for="cat_veg">Vegetarian</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="category" id="cat_non_veg" value="non_veg" <?php echo e(old('category') === 'non_veg' ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="cat_non_veg">Non-vegetarian</label>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label for="quantity" class="form-label required">Quantity</label>
                <input type="text" class="form-control" id="quantity" name="quantity" value="<?php echo e(old('quantity')); ?>" required placeholder="e.g. 20 boxes">
            </div>
            <div class="mb-3">
                <label for="photo" class="form-label">Photo (optional)</label>
                <input type="file" class="form-control" id="photo" name="photo" accept="image/*">
                <div class="form-text">Stored locally under storage/app/public (run php artisan storage:link).</div>
            </div>
            <div class="mb-3">
                <label for="expiry_at" class="form-label required">Expiry date &amp; time</label>
                <input type="datetime-local" class="form-control" id="expiry_at" name="expiry_at" value="<?php echo e(old('expiry_at')); ?>" required>
            </div>
            <button type="submit" class="btn btn-brand">Save listing</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\donor\donations\create.blade.php ENDPATH**/ ?>