<?php if(!empty($api['usesListingId'])): ?>
    <div class="listing-picker-wrap <?php echo e(str_contains($api['path'], 'claim') ? 'claim' : ''); ?>">
        <label>Listing ID for this request</label>
        <div class="listing-id-row">
            <div>
                <select class="listing-id-select" data-api="<?php echo e($api['id']); ?>">
                    <option value="">Select listing…</option>
                </select>
            </div>
            <div class="id-manual">
                <input type="number" class="listing-id-local" data-api="<?php echo e($api['id']); ?>" placeholder="ID">
            </div>
        </div>
        <p class="picker-hint">Uses this ID in the URL: <?php echo e($api['path']); ?></p>
    </div>
<?php endif; ?>
<?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\test-apis\partials\listing-picker.blade.php ENDPATH**/ ?>