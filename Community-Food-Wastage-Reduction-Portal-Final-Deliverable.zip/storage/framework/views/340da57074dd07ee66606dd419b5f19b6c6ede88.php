

<?php $__env->startSection('title', 'Volunteer tasks'); ?>

<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('partials.volunteer_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title h4 mb-0">Pickup tasks</h1>
</div>

<p class="small text-muted">CLAIMED listings waiting for pickup. Mark complete when food is delivered.</p>

<div class="card page-card">
    <div class="card-body p-0 table-responsive">
        <table class="table table-striped mb-0">
            <thead>
                <tr>
                    <th>Food</th>
                    <th>NGO</th>
                    <th>Donor</th>
                    <th>Pickup</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($task->title); ?> <span class="badge badge-claimed"><?php echo e($task->status); ?></span></td>
                        <td class="small"><?php echo e($task->claimedBy->ngo_name ?? $task->claimedBy->name ?? '—'); ?></td>
                        <td class="small"><?php echo e($task->donor->business_name ?? $task->donor->name); ?></td>
                        <td class="small"><?php echo e($task->pickup_address); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(url('/volunteer/tasks/'.$task->id.'/complete')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-brand" data-confirm="Mark this pickup as completed (DELIVERED)?">Complete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="text-muted p-3">No active pickup tasks.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\volunteer\tasks\index.blade.php ENDPATH**/ ?>