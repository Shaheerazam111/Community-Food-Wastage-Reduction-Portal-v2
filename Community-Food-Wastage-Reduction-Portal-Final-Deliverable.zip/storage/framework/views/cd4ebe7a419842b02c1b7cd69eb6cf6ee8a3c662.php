<li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>" href="<?php echo e(url('/admin/dashboard')); ?>">Dashboard</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/reports*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.reports')); ?>">Reports</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.users')); ?>">Users</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/verification*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.verification')); ?>">NGO docs</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/listings*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.listings')); ?>">Moderate food</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->is('notifications') ? 'active' : ''); ?>" href="<?php echo e(url('/notifications')); ?>">Notifications</a></li>
<li class="nav-item"><a class="nav-link <?php echo e(request()->is('profile') ? 'active' : ''); ?>" href="<?php echo e(url('/profile')); ?>">Profile</a></li>
<?php /**PATH D:\ashir\Community-Food-Wastage-Reduction-Portal-v2\resources\views\partials\admin_nav.blade.php ENDPATH**/ ?>